// This file is intentionally left empty as all the content is static in the HTML file
